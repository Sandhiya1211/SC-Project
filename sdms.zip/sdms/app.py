from flask import Flask, render_template, request, redirect, session
from db_config import get_db_connection

app = Flask(__name__)
app.secret_key = 'your_secret_key'


@app.route('/')
def index():
    return render_template('login.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        role = request.form['role']
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Determine the correct table based on role
        if role == 'admin':
            cursor.execute("SELECT * FROM admin WHERE username = %s", (username,))
        elif role == 'faculty':
            cursor.execute("SELECT * FROM faculty WHERE username = %s", (username,))
        elif role == 'student':
            cursor.execute("SELECT * FROM students WHERE username = %s", (username,))
        else:
            conn.close()
            return "Invalid role selected."

        user = cursor.fetchone()
        conn.close()

        if user and user['password'] == password:  # You can replace this with hashed check
            session['username'] = user['username']
            session['role'] = role

            # Redirect to role-specific dashboard
            if role == 'admin':
                return redirect('/admin')
            elif role == 'faculty':
                return redirect('/faculty')
            elif role == 'student':
                return redirect('/student')
        else:
            return "Invalid username or password."

    return render_template('login.html')

@app.route('/logout', methods=['POST'])
def logout():
    session.clear()  # Clears all session data
    return redirect(url_for('login'))  # Redirect to login page

@app.route('/admin')
def admin_dashboard():
    if 'role' not in session or session['role'] != 'admin':
        return redirect('/')

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM students")
    students = cursor.fetchall()

    cursor.execute("SELECT * FROM faculty")
    faculty = cursor.fetchall()
    conn.close()

    return render_template('admin_dashboard.html', students=students, faculty=faculty)


# -------- Faculty Routes --------

@app.route('/admin/faculty')
def view_faculty():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM faculty")
    faculty_list = cursor.fetchall()
    conn.close()
    return render_template("faculty_list.html", faculty=faculty_list)

@app.route('/admin/add-faculty', methods=['GET', 'POST'])
def add_faculty():
    if request.method == 'POST':
        id = request.form['id']
        name = request.form['name']
        username = request.form['username']
        email = request.form['email']
        password =request.form['password']
        assigned_courses = request.form['assigned_courses']  # Use .get() to handle missing field

        # Establish the connection to the database
        conn = get_db_connection()
        cursor = conn.cursor()

        # Insert the data into the faculty table
        cursor.execute("INSERT INTO faculty (id,name,username, email,password, assigned_courses) VALUES (%s,%s,%s,%s, %s, %s)",
                       (id,name,username, email,password, assigned_courses))
        conn.commit()  # Commit the transaction
        conn.close()   # Close the connection

        return redirect('/admin/faculty')
    return render_template("add_faculty.html")



@app.route('/admin/edit-faculty/<string:id>', methods=['GET', 'POST'])
def edit_faculty(id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        assigned_courses = request.form['assigned_courses']
        cursor.execute("UPDATE faculty SET name=%s, email=%s, assigned_courses=%s WHERE id=%s", (name, email, assigned_courses,id))
        conn.commit()
        conn.close()
        return redirect('/admin/faculty')

    cursor.execute("SELECT * FROM faculty WHERE id=%s", (id,))
    faculty = cursor.fetchone()
    conn.close()
    return render_template("edit_faculty.html", faculty=faculty)


@app.route('/admin/delete-faculty/<string:id>')
def delete_faculty(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM faculty WHERE id=%s", (id,))
    conn.commit()
    conn.close()
    return redirect('/admin/faculty')


# -------- Student Routes --------

@app.route('/admin/student')
def view_students():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Join students with enrollments and courses
    cursor.execute("""
        SELECT s.id, s.name, s.username, s.email, s.attendance, s.grades,
               GROUP_CONCAT(c.course_name SEPARATOR ', ') AS enrolled_courses
        FROM students s
        LEFT JOIN enrollments e ON s.id = e.student_id
        LEFT JOIN courses c ON e.course_code = c.course_code
        GROUP BY s.id, s.name, s.username, s.email, s.attendance, s.grades
    """)
    student_list = cursor.fetchall()
    conn.close()
    return render_template("student_list.html", students=student_list)


@app.route('/admin/add-student', methods=['GET', 'POST'])
def add_student():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        student_id = request.form['id']
        name = request.form['name']
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        courses = request.form.getlist('courses')  # Get selected courses as a list

        # Insert into students table
        cursor.execute(
            "INSERT INTO students (id, name, username, email, password) VALUES (%s, %s, %s, %s, %s)",
            (student_id, name, username, email, password)
        )

        # Insert into enrollments table
        for course_code in courses:
            cursor.execute(
                "INSERT INTO enrollments (student_id, course_code) VALUES (%s, %s)",
                (student_id, course_code)  # Use course_code here, not course_id
            )

            # Update the enrolled students count for the course
            cursor.execute("""
                UPDATE courses
                SET enrolled_students_count = enrolled_students_count + 1
                WHERE course_code = %s
            """, (course_code,))  # Use course_code here

        conn.commit()
        conn.close()
        return redirect('/admin/student')

    # Fetch available courses to show in the form
    cursor.execute("SELECT course_code, course_name FROM courses")
    courses = cursor.fetchall()
    conn.close()
    return render_template("add_student.html", courses=courses)


@app.route('/admin/edit-student/<string:id>', methods=['GET', 'POST'])
def edit_student(id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        attendance = request.form['attendance']
        grades = request.form['grades']
        courses = request.form['courses']
        cursor.execute("""
            UPDATE students
            SET name = %s,email = %s, attendance = %s, grades = %s, courses = %s
            WHERE id = %s
        """, (name, email, attendance, grades, courses, id))

        conn.commit()
        conn.close()
        return redirect('/admin/student')

    cursor.execute("SELECT * FROM students WHERE id = %s", (id,))
    student = cursor.fetchone()
    conn.close()
    return render_template("edit_student.html", student=student)
  

@app.route('/admin/delete-student/<string:id>')
def delete_student(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM enrollments WHERE student_id = %s", (id,))
    cursor.execute("DELETE FROM students WHERE id=%s", (id,))
    conn.commit()
    conn.close()
    return redirect('/admin/student')

@app.route('/admin/courses')
def view_courses():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("""
        SELECT 
            c.course_code, 
            c.course_name, 
            f.name AS faculty_name, 
            COUNT(e.student_id) AS student_count
        FROM courses c
        LEFT JOIN faculty f ON c.faculty_id = f.id
        LEFT JOIN enrollments e ON c.course_code = e.course_code
        GROUP BY c.course_code, c.course_name, f.name
    """)
    
    courses = cursor.fetchall()
    conn.close()
    return render_template('admin_courses.html', courses=courses)

@app.route('/admin/add-course', methods=['GET', 'POST'])
def add_course():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        course_code = request.form['course_code']
        course_name = request.form['course_name']
        faculty_id = request.form['faculty_id']

        # Add course
        cursor.execute("INSERT INTO courses (course_code, course_name, faculty_id) VALUES (%s, %s, %s)",
                       (course_code, course_name, faculty_id))

        # Get faculty's username to update assigned_courses
        cursor.execute("SELECT username, assigned_courses FROM faculty WHERE id = %s", (faculty_id,))
        faculty = cursor.fetchone()

        if faculty:
            current_courses = faculty['assigned_courses']
            course_list = [c.strip() for c in current_courses.split(',')] if current_courses else []
            new_course_entry = course_name
            if new_course_entry not in course_list:
                course_list.append(new_course_entry)
                updated_courses = ', '.join(course_list)
                cursor.execute("UPDATE faculty SET assigned_courses = %s WHERE id = %s", (updated_courses, faculty_id))

        conn.commit()

    # Faculty dropdown list
    cursor.execute("SELECT id, name FROM faculty")
    faculty_list = cursor.fetchall()

    # All course list with faculty name and student count
    cursor.execute("""
        SELECT 
            c.course_code,
            c.course_name,
            f.name AS faculty_name,
            COUNT(e.student_id) AS student_count
        FROM courses c
        LEFT JOIN faculty f ON c.faculty_id = f.id
        LEFT JOIN enrollments e ON c.course_code = e.course_code
        GROUP BY c.course_code, c.course_name, f.name
    """)

    courses = cursor.fetchall()
    conn.close()
    return render_template("add_course.html", faculty=faculty_list, courses=courses)

@app.route('/admin/delete-course/<course_code>')
def delete_course(course_code):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM courses WHERE course_code=%s", (course_code,))
    conn.commit()
    conn.close()
    return redirect('/admin/add-course')
@app.route('/admin/edit-course/<course_code>', methods=['GET', 'POST'])
def edit_course(course_code):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        course_name = request.form['course_name']
        faculty_id = request.form['faculty_id']
        cursor.execute("UPDATE courses SET course_name=%s, faculty_id=%s WHERE course_code=%s",
                       (course_name, faculty_id, course_code))
        conn.commit()
        conn.close()
        return redirect('/admin/add-course')

    # Get course details
    cursor.execute("SELECT * FROM courses WHERE course_code=%s", (course_code,))
    course = cursor.fetchone()

    # Get faculty list
    cursor.execute("SELECT id, name FROM faculty")
    faculty = cursor.fetchall()

    conn.close()
    return render_template('edit_course.html', course=course, faculty=faculty)

@app.route('/admin/course/<course_code>')
def course_info(course_code):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Get course details
    cursor.execute("SELECT course_name FROM courses WHERE course_code = %s", (course_code,))
    course = cursor.fetchone()

    if not course:
        conn.close()
        return "Course not found", 404

    # Get students enrolled in this course
    cursor.execute("""
        SELECT id, name, attendance, grades
        FROM students
        WHERE FIND_IN_SET(%s, courses) > 0
    """, (course_code,))

    students = cursor.fetchall()
    conn.close()

    # Parse attendance and grades strings for each student
    for student in students:
        student['attendance_percentage'] = None
        student['grade'] = None
        
        # Parse attendance string
        if student['attendance']:
            attendance_dict = dict(item.split(":") for item in student['attendance'].split(","))
            student['attendance_percentage'] = attendance_dict.get(course_code)
        
        # Parse grades string
        if student['grades']:
            grades_dict = dict(item.split(":") for item in student['grades'].split(","))
            student['grade'] = grades_dict.get(course_code)

    return render_template('course_info.html', course=course, students=students, course_code=course_code)

# -------- Dashboards --------

@app.route('/faculty')
def faculty_dashboard():
    if session.get('role') != 'faculty':
        return redirect('/')

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM Faculty WHERE username = %s", (session['username'],))
    faculty = cursor.fetchone()
    conn.close()

    if not faculty:
        return "Faculty record not found."

    return render_template('faculty_dashboard.html', faculty=faculty)

@app.route('/faculty/courses')
def view_assigned_courses():
    if session.get('role') != 'faculty':
        return redirect('/')

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Fetch the faculty record
    cursor.execute("SELECT assigned_courses FROM Faculty WHERE username = %s", (session['username'],))
    faculty = cursor.fetchone()

    if not faculty:
        conn.close()
        return "Faculty record not found."

    assigned_courses = faculty['assigned_courses']

    if not assigned_courses:
        conn.close()
        return render_template('faculty_courses.html', courses=[])

    # Split comma-separated course codes and prepare query
    course_codes = [code.strip() for code in assigned_courses.split(',')]
    format_strings = ','.join(['%s'] * len(course_codes))

    # Fetch course details
    query = f"SELECT * FROM Courses WHERE course_code IN ({format_strings})"
    cursor.execute(query, tuple(course_codes))
    courses = cursor.fetchall()

    conn.close()
    return render_template('faculty_courses.html', courses=courses)

import json  # make sure this is at the top of your file

@app.route('/faculty/course/<course_code>/grades', methods=['GET', 'POST'])
def mark_grades(course_code):
    if session.get('role') != 'faculty':
        return redirect('/')

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Verify faculty assignment
    cursor.execute("SELECT assigned_courses FROM Faculty WHERE username = %s", (session['username'],))
    faculty = cursor.fetchone()
    if not faculty:
        conn.close()
        return "Faculty record not found."

    assigned_courses = faculty['assigned_courses']
    course_list = [c.strip().upper() for c in assigned_courses.split(',')] if assigned_courses else []

    if course_code.upper() not in course_list:
        conn.close()
        return f"You are not assigned to this course. Assigned: {course_list}, Requested: {course_code.upper()}"

    if request.method == 'POST':
        grades = request.form.getlist('grade')
        student_ids = request.form.getlist('student_id')

        return redirect(f'/faculty/course/{course_code}/grades')
    
    # GET method: fetch students and their grades
    cursor.execute("""
        SELECT s.id, s.name, e.grade
        FROM students s
        JOIN enrollments e ON s.id = e.student_id
        WHERE e.course_code = %s
    """, (course_code,))
    students = cursor.fetchall()
    conn.close()

    return render_template('assign_grades.html', course_code=course_code, students=students)


@app.route('/faculty/course/<course_code>/attendance', methods=['GET', 'POST'])
def mark_attendance(course_code):
    if session.get('role') != 'faculty':
        return redirect('/')

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Verify faculty assignment
    cursor.execute("SELECT assigned_courses FROM Faculty WHERE username = %s", (session['username'],))
    faculty = cursor.fetchone()
    if not faculty:
        conn.close()
        return "Faculty record not found."

    assigned_courses = faculty['assigned_courses']
    course_list = [c.strip().upper() for c in assigned_courses.split(',')] if assigned_courses else []

    if course_code.upper() not in course_list:
        conn.close()
        return f"You are not assigned to this course."

    if request.method == 'POST':
        percentages = request.form.getlist('attendance')
        student_ids = request.form.getlist('student_id')

        for student_id, percentage in zip(student_ids, percentages):
            try:
                attendance = float(percentage)
            except ValueError:
                attendance = None  # skip or mark as null

            # Update enrollments table
            cursor.execute("""
                UPDATE enrollments 
                SET attendance_percentage = %s 
                WHERE student_id = %s AND course_code = %s
            """, (attendance, student_id, course_code))

            # Update students table if needed
            cursor.execute("SELECT attendance FROM students WHERE id = %s", (student_id,))
            result = cursor.fetchone()

            if result:
                current_attendance = result['attendance']
                try:
                    attendance_dict = json.loads(current_attendance) if current_attendance else {}
                except:
                    attendance_dict = {}
            else:
                continue

            if attendance is not None:
                attendance_dict[course_code.upper()] = attendance
            else:
                attendance_dict.pop(course_code.upper(), None)

            cursor.execute("UPDATE students SET attendance = %s WHERE id = %s",
                           (json.dumps(attendance_dict), student_id))

        conn.commit()
        conn.close()
        return redirect(f'/faculty/course/{course_code}/attendance')

    # GET method: show students enrolled in this course
    cursor.execute("""
        SELECT s.id, s.name, e.attendance_percentage
        FROM students s
        JOIN enrollments e ON s.id = e.student_id
        WHERE e.course_code = %s
    """, (course_code,))
    students = cursor.fetchall()
    conn.close()

    return render_template('mark_attendance.html', course_code=course_code, students=students)

import json
def safe_json_loads(s):
    if not s:
        return {}
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        return {}

def parse_grades(grade_str):
    if not grade_str:
        return {}
    try:
        return dict(pair.split(':') for pair in grade_str.split(',') if ':' in pair)
    except Exception as e:
        print("Error parsing grades:", e)
        return {}

@app.route('/student')
def student_dashboard():
    if session.get('role') != 'student':
        return redirect('/')

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM Students WHERE username = %s", (session['username'],))
    row = cursor.fetchone()

    if not row:
        return "Student not found", 404

    student = {
        'name': row['name'],
        'email': row['email'],
        'courses': row['courses'].split(',') if row['courses'] else [],
        'attendance': safe_json_loads(row.get('attendance')),
        'grades': parse_grades(row.get('grades')),
    }

    return render_template('student_dashboard.html', student=student)


    conn.close()

    if not student:
        return "Student record not found."

    return render_template('student_dashboard.html', student=student)
from flask import Flask, redirect, url_for, session, render_template, request

if __name__ == '__main__':
    app.run(debug=True)
